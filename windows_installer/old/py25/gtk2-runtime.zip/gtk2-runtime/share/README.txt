
GTK+ themes and theme engines for Windows32.

Packaged and compiled by Alexander Shaduri <ashaduri 'at' gmail.com>

The latest version may be obtained at
http://gtk-win.sourceforge.net

You will need at least GTK+ version 2.10.0 for installation.
Unpack to wherever your GTK+ is installed.

For more information about GTK+ visit http://www.gtk.org


