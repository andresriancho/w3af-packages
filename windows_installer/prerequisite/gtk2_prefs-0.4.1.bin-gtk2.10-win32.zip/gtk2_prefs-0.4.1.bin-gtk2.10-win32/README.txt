
gtk2_prefs:
GTK+ version 2 preference utility - theme and font switcher
by Alex Shaduri <ashaduri 'at' gmail.com>

The latest version may be obtained at
http://members.lycos.co.uk/alexv6

You will need at least GTK+ version 2.4.0 for installation.

For more information about GTK+ visit http://www.gtk.org


